/**
 * Obsługa panelu logowania
 * 
 * @copyright Copyright &copy; 2011, NetArt
 * @author Dawid Stępień <dawid.stepien@netart.pl>
 */
function uuid()
{
    function hex(len, x)
    {
        if (x === undefined)
        {
            x = Math.random();
        }
        
        var s = new Array(len);
        
        for(var i = 0; i < len; i++)
        {
            x *= 16;
            var digit = x & 15;
            s[i] = digit + (digit < 10 ? 48 : 87); // '0' and 'a' - 10
        }
        
        return String.fromCharCode.apply(String, s);
    }
    
    return [hex(8), "-", hex(4), "-4", hex(3), "-", hex(4, 0.5 + Math.random() / 4), "-", hex(12)].join("");
}

/**
 * Obiekt strony
 */
var pageObject = function(id)
{
    var self = {};
    var cls  = 'page';
    var config = {};
    var shown = false;
    
    self.setConfig = function(config)
    {
        self.config = config;
    }
    
    self.addConfig = function(config)
    {
        self.setConfig($.extend(self.getConfig(), config));
    }
    
    self.getConfig = function()
    {
        return self.config;
    }
    
    self.show = function()
    {
        if(self.getId())
        {
            if($('.' + self.getCls() + ':visible').length)
            {
                $('.' + self.getCls() + ':visible').fadeOut('normal', function()
                {
                    $(self.getIdSelector()).fadeIn();
                });
            }
            else
            {
                $(self.getIdSelector()).show();
            }
            
            self.setShown();
        }
        
        return self;
    }
    
    self.setShown = function()
    {
       shown = true;
    }
    
    self.isShown = function()
    {
        return shown;
    }
    
    self.getId = function()
    {
        return id;
    }
    
    self.getCls = function()
    {
        return cls;
    }
    
    self.getIdSelector = function()
    {
        return '#' + self.getId();
    }
    
    return self;
}

/**
 * Obiekt formularza logowania 
 */
var loginFormObject = function()
{
    var self = new pageObject('loginForm');
    
    self.form = $(self.getIdSelector() + ' form');
    
    self.error = function(text)
    {
        if(text)
        {
            $('#loginError').html(text);
        }
        else
        {
            $('#loginError').html('&nbsp;');
        }
        
        return $('#loginError');
    }
    
    self.setAction = function(action)
    {
        return self.form.attr('action', action);
    }
    
    return self;
}

/**
 * Obiekt loadera
 */
var loaderObject = function()
{
    var self = new pageObject('loader');
    
    self.setHtml = function(html)
    {
        $(self.getIdSelector() + ' span').html(html);
        return self;
    }
    
    return self;
}

/**
 * Obiekt wizarda
 */
var wizardObject = function(config)
{
    var self = new pageObject('wizard');
    var currentTabNo = 0;
    var tabStartNo = 0;
    var tabCls = 'tab';
    var tabCallbacks = {};
    var callbacks = [];
    
    self.buttons = {
        next  : $('#btnNext'),
        prev  : $('#btnPrev'),
        start : $('#btnStart')
    }
    
    self.setTabStartNo = function(no)
    {
        tabStartNo = no;
    }
    
    self.setCurrentTabNo = function(no)
    {
        currentTabNo = no;
        tabStartNo = no;
    }
    
    self.showTab = function(tabNo)
    {
        if(!self.isShown())
        {
            self.show();
        }
        
        if(!tabNo)
        {
            self.doCallbacks();
            tabNo = currentTabNo;
        }
        
        self.tabConfigure(tabNo);
        
        if($('.' + tabCls + ':visible').length)
        {
            $('.' + tabCls + ':visible').fadeOut('normal', function()
            {
                $('.' + tabCls).eq(tabNo).fadeIn();
            });
        }
        else
        {
            $('.' + tabCls).eq(tabNo).show();
        }
        
        return self;
    }
    
    self.btnConfigure = function()
    {
        self.buttons.next.click(function()
        {
            if((currentTabNo + 1) < $('.' + tabCls).length && $('.' + tabCls).eq(currentTabNo).is(':visible'))
            {
                self.showTab(++currentTabNo);
            }
        });
        
        self.buttons.prev.click(function()
        {
            if(currentTabNo > tabStartNo && $('.' + tabCls).eq(currentTabNo).is(':visible'))
            {
                self.showTab(--currentTabNo);
            }
        });
        
        return self;
    }
    
    self.tabConfigure = function(tabNo)
    {
        switch(tabNo)
        {
            case 0 :
            case 3 :
            {
                self.buttons.next.show();
                self.buttons.prev.hide();
                self.buttons.start.hide();
                break;
            }
            case 1 :
            case 4 :
            {
                self.buttons.next.show();
                self.buttons.prev.show();
                self.buttons.start.hide();
                break;
            }
            case 2 :
            case 5 :
            {
                self.buttons.next.hide();
                self.buttons.prev.show();
                self.buttons.start.show();
                break;
            }
        }
        
        if($.isFunction(self.getTabCallback(tabNo)))
        {
            self.tabCallback(tabNo);
        }
        
        return self;
    }
    
    self.getTabCallback = function(tabNo)
    {
        return tabCallbacks[tabNo];
    }
    
    self.addTabCallback = function(callback, tabNo)
    {
        tabCallbacks[tabNo] = callback;
    }
    
    self.tabCallback = function(tabNo)
    {
        var callback = self.getTabCallback(tabNo);
        callback(self);
    }
    
    self.getCallbacks = function()
    {
        return self.callbacks;
    }
    
    self.addCallback = function(callback)
    {
        if($.isFunction(callback))
        {
            callbacks.push(callback);
        }
    }
    
    self.doCallbacks = function()
    {
        for(i in callbacks)
        {
            var callback = callbacks[i];
            callback(self);
        }
        
        return self;
    }
    
    self.reset = function()
    {
        currentTabNo = tabStartNo;
        
        return self;
    }

    self.btnConfigure();
    
    return self;
}

var migrationStatusClient = function(host, username, password)
{
    var self = this;
    /*
     * Akcje
     */
    self.CHECK_STATUS = 'CHECK_STATUS';
    self.START_MIGRATION = 'START_MIGRATION';
    self.CLEAR_ACCOUNT = 'CLEAR_ACCOUNT';
    self.SKIP_MIGRATION = 'SKIP_MIGRATION';
    self.CREATE_USER = 'CREATE_USER';
    
    /*
     * Statusy
     */
    self.UNKNOWN = 'UNKNOWN';
    self.WAITING_FOR_AUTOMATIC_MIGRATION = 'WAITING_FOR_AUTOMATIC_MIGRATION';
    self.WAITING_FOR_REMOVAL = 'WAITING_FOR_REMOVAL';
    self.MIGRATION_PENDING = 'MIGRATION_PENDING';
    self.MIGRATION_SUCCEED = 'MIGRATION_SUCCEED';
    self.MIGRATION_FAILED = 'MIGRATION_FAILED';
    self.MIGRATION_IN_BETA_PHASE = 'MIGRATION_IN_BETA_PHASE';
    self.WAITING_FOR_REMOVAL = 'WAITING_FOR_REMOVAL';
    self.NOT_AUTHENTICATED = 'NOT_AUTHENTICATED';
    
    self.host = host;
    self.username = username;
    self.password = password;
    
    self.post = function(action)
    {
        try
        {
            if(self.host)
            {
                var result = $.parseJSON($.ajax(
                {
                    type : 'POST',
                    url  : self.host,
                    data : {
                        action   : action,
                        username : self.username,
                        password : self.password
                    },
                    async : false
                }).responseText);
            }
            else
            {
                throw "ERROR";
            }
        }
        catch(e)
        {
            return "ERROR";
        }
        
        return result.data;
    }
    
    self.getStatus = function()
    {
        return self.post(self.CHECK_STATUS);
    }
}